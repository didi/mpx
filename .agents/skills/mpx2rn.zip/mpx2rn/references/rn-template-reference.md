# 跨端输出 RN 模板能力参考

## 目录

- [数据绑定](#数据绑定)
  - [文本、属性与表达式](#文本属性与表达式)
- [模板指令](#模板指令)
- [事件处理](#事件处理)
  - [通用事件](#通用事件)
  - [事件绑定语法](#事件绑定语法)
  - [注意事项](#注意事项-1)
- [Slot](#slot)
  - [默认插槽](#默认插槽)
  - [具名插槽与 `multipleSlots`](#具名插槽与-multipleslots)
- [WXML 模板](#wxml-模板)
  - [模板内联定义](#模板内联定义)
  - [import 外联引入](#import-外联引入)
  - [注意事项](#注意事项-2)
- [i18n 国际化](#i18n-国际化)
  - [工程配置示例](#工程配置示例)
  - [模板中使用翻译函数](#模板中使用翻译函数)
  - [JS 中使用翻译函数](#js-中使用翻译函数)
  - [注意事项](#注意事项-3)
- [无障碍访问](#无障碍访问)
  - [模板属性](#模板属性)
  - [示例](#示例)
  - [注意事项](#注意事项-4)
- [基础组件](#基础组件)
  - [通用属性](#通用属性)
  - [view](#view)
  - [text](#text)
  - [scroll-view](#scroll-view)
  - [swiper](#swiper)
  - [swiper-item](#swiper-item)
  - [movable-area](#movable-area)
  - [movable-view](#movable-view)
  - [image](#image)
  - [icon](#icon)
  - [button](#button)
  - [label](#label)
  - [checkbox](#checkbox)
  - [checkbox-group](#checkbox-group)
  - [radio](#radio)
  - [radio-group](#radio-group)
  - [form](#form)
  - [input](#input)
  - [textarea](#textarea)
  - [progress](#progress)
  - [picker-view](#picker-view)
  - [picker-view-column](#picker-view-column)
  - [picker](#picker)
  - [slider](#slider)
  - [switch](#switch)
  - [navigator](#navigator)
  - [rich-text](#rich-text)
  - [canvas](#canvas)
  - [camera](#camera)
  - [video](#video)
  - [web-view](#web-view)
  - [root-portal](#root-portal)
  - [sticky-section](#sticky-section)
  - [sticky-header](#sticky-header)
  - [cover-view](#cover-view)
  - [cover-image](#cover-image)

---

## 数据绑定

跨端输出 RN 时，模板数据绑定规则与微信小程序一致：在模板中使用 Mustache 语法 `{{}}` 将脚本中的响应式数据、计算属性等绑定到视图。编译后由 Mpx 在 RN 侧生成等价的数据流与属性传递，写法上与输出小程序、Web 保持同一套 `.mpx` 模板习惯即可。

### 文本、属性与表达式

- **文本节点**：在标签闭合内容中使用 Mustache 表达式插值，例如 `<text>{{ message }}</text>`。
- **属性值**：属性值同样支持 Mustache 表达式插值，例如 `value="{{ inputValue }}"`、`placeholder="共 {{ total }} 条"`，同时支持在模版指令中使用，如 `wx:if`、`wx:for`、`wx:show` 等。
- **表达式能力**：`{{}}` 内支持算术、三元、逻辑运算、属性访问等常见 JavaScript 表达式，可与 `data`、`computed`、`setup` 暴露的数据字段组合使用。`{{}}` 内支持**可选链** `?.`，例如 `{{ user?.name }}`、`wx:if="{{ list?.length }}"`。
- **访问环境变量**：在 `{{}}` 中可直接访问 **`__mpx_mode__`**（当前目标平台，如 `wx`、`ali`、`ios`、`android` 等）、**`__mpx_env__`**（用户在编译配置中通过 `env` 定义的环境标识），以及用户在编译配置中通过 **`defs`** 定义的自定义环境变量。

```html
<template>
  <!-- 不推荐：在 {{}} 中直接调用 methods 或任意函数 -->
  <!-- <text>{{ formatTitle(title) }}</text> -->

  <!-- 推荐：绑定 computed / data 字段 -->
  <text>{{ displayTitle }}</text>

  <!-- i18n：翻译方法由编译器改写，可按项目 i18n 文档使用 -->
  <text>{{ $t('hello') }}</text>
</template>

<script>
import { createComponent } from '@mpxjs/core'

createComponent({
  data () {
    return {
      title: 'demo'
    }
  },
  computed: {
    displayTitle () {
      return this.formatTitle(this.title)
    }
  },
  methods: {
    formatTitle (str) {
      return str ? str.toUpperCase() : ''
    }
  }
})
</script>
```

#### 注意事项

1. 模板数据绑定中**不支持**对组件 `methods` 或任意函数的**一般方法调用**（例如 `{{ formatTitle(title) }}`）。
2. 需要在模版中加工展示数据时，请使用 **`computed`** 替代，或改写为 **`wxs`** 函数，模版中支持调用 `wxs` 函数。
3. **例外**：**i18n 翻译函数**（如 `$t`、`$tc` 等，组合式 API 中为 `t`、`tc` 等）会在**编译期**被 Mpx **改写为等效的 `computed` 或 `wxs` 实现**，因此模板中支持直接调用 i18n 翻译函数。

---

## 模板指令

Mpx 跨端输出 RN 时，支持以下模板指令。

| 指令 | 支持状态 | 说明 | 示例 |
| --- | --- | --- | --- |
| wx:if | ✅ | 条件渲染 | `<view wx:if="{{condition}}">...</view>` |
| wx:else | ✅ | 条件渲染 | `<view wx:else>...</view>` |
| wx:elif | ✅ | 条件渲染 | `<view wx:elif="{{condition}}">...</view>` |
| wx:show | ✅ | 显示/隐藏控制 | `<view wx:show="{{isVisible}}">...</view>` |
| wx:for | ✅ | 列表渲染 | `<view wx:for="{{list}}">...</view>` |
| wx:for-item | ✅ | 指定循环项变量名 | `<view wx:for="{{list}}" wx:for-item="item">...</view>` |
| wx:for-index | ✅ | 指定循环索引变量名 | `<view wx:for="{{list}}" wx:for-index="idx">...</view>` |
| wx:class | ✅ | 动态类名绑定 | `<view wx:class="{{ {active: isActive} }}">...</view>` |
| wx:style | ✅ | 动态样式绑定 | `<view wx:style="{{ {color: colorVar} }}">...</view>` |
| wx:model | ✅ | 双向数据绑定 | `<input wx:model="{{value}}" />` |
| wx:model-prop | ✅ | 双向绑定属性 | `<custom-input wx:model="{{value}}" wx:model-prop="myValue" />` |
| wx:model-event | ✅ | 双向绑定事件 | `<custom-input wx:model="{{value}}" wx:model-event="myChange" />` |
| wx:model-value-path | ✅ | 定义了双向绑定时从 `e.detail` 中获取更新值的访问路径，默认值为 `value`，即通过 `e.detail.value` 获取更新值，如通过 `e.detail` 直接作为更新值，可以设置 `wx:model-value-path="[]"` | `<custom-input wx:model="{{value}}" wx:model-value-path="[]" />` |
| wx:model-filter | ✅ | 双向绑定过滤器，可绑定内建（如 trim）或组件实例方法，在双向绑定时对更新值进行过滤和修饰 | `<input wx:model="{{value}}" wx:model-filter="trim" />` |
| wx:ref | ✅ | 获取基础组件节点或自定义组件实例 | `<view wx:ref="myView">...</view>` |

---

## 事件处理

### 通用事件

在跨端输出 RN 时，所有基础组件均支持以下基础通用事件，并且支持事件冒泡和捕获。

| 事件名      | 说明                                   |
| ----------- | -------------------------------------- |
| tap         | 手指触摸后马上离开                     |
| longpress   | 手指触摸后，超过 350ms 再离开          |
| touchstart  | 手指触摸动作开始                       |
| touchmove   | 手指触摸后移动                         |
| touchend    | 手指触摸动作结束                       |
| touchcancel | 手指触摸动作被打断，如来电提醒，弹窗等 |

### 事件绑定语法

**普通事件绑定**

```js
<view bindtap="handleTap">Click here!</view>
```

**绑定并阻止事件冒泡**

```js
<view catchtap="handleTap">Click here!</view>
```

**事件捕获**

```js
<view capture-bind:touchstart="handleTap1">
  outer view
  <view capture-bind:touchstart="handleTap2">inner view</view>
</view>
```

**中断捕获阶段和取消冒泡阶段**

```js
<view capture-catch:touchstart="handleTap1">outer view</view>
```

**事件内联传参**

Mpx 支持了事件内联传参机制。

```html
<template>
  <!--Mpx增强语法，模板内联传参，方便简洁-->
  <view bindtap="handleTapInline('inline')">内联传参</view>
</template>
<script>
import { createComponent } from '@mpxjs/core'

createComponent({
  methods: {
    handleTapInline (params) {
      console.log('params:', params)
    }
  }
})
</script>
```

**动态事件绑定**

Mpx 也支持使用 `{{}}` 插值进行动态事件绑定。

```html
<template>
  <!--动态事件绑定-->
  <view wx:for="{{items}}" bindtap="handleTap_{{index}}"> {{item}} </view>
</template>
<script>
import { createComponent } from '@mpxjs/core'

createComponent({
  data () {
    return {
      items: ['Item 1', 'Item 2', 'Item 3', 'Item 4']
    }
  },
  methods: {
    handleTap_0 () {
      console.log('Tapped on item 1')
    },
    handleTap_1 () {
      console.log('Tapped on item 2')
    },
    handleTap_2 () {
      console.log('Tapped on item 3')
    },
    handleTap_3 () {
      console.log('Tapped on item 4')
    }
  }
})
</script>
```

### 注意事项

1. 除基础通用事件外，其余所有事件均不支持事件冒泡和捕获。
2. 由于 `tap` 和 `longpress` 事件是由 `touchstart` / `touchend` 等底层触摸事件模拟实现，所以在 RN 环境，如果子组件绑定了 `catchtouchend`，那么父组件的 `tap` 事件将不会响应。
3. 如果元素上设置了 `opacity: 0` 的样式，会导致 ios 事件无法响应。
4. 传递自定义参数给事件处理器时，优先使用**事件内联传参**语法（如 `bindtap="handleTap('param')"`），而不是通过 `data-` dataset 属性传参。

---

## Slot

插槽（slot）：跨端输出 RN 时，**自定义组件插槽能力与微信小程序一致，已完整支持**：在组件模板中使用 `<slot>` 承载引用方传入的子节点；编译后在 RN 侧走与小程序等价的组合与渲染路径。

### 默认插槽

组件内提供一个无 `name` 的 `<slot></slot>`，引用组件时写在标签内部的子节点会渲染到该位置。

```html
<!-- child.mpx 组件模板 -->
<template>
  <view class="wrapper">
    <view>组件内部结构</view>
    <slot></slot>
  </view>
</template>
```

```html
<!-- 引用方 -->
<child>
  <view>这段会出现在默认 slot 位置</view>
</child>
```

### 具名插槽与 `multipleSlots`

默认每个组件模板中只有一个插槽。若需要多个插槽，在 `createComponent` 的 **`options.multipleSlots`** 中设为 **`true`**，在模板里用 **`<slot name="...">`** 区分；引用方在子节点上使用 **`slot="..."`** 指定落入哪个插槽。

```js
createComponent({
  options: {
    multipleSlots: true
  }
})
```

```html
<!-- 组件模板 -->
<template>
  <view class="wrapper">
    <slot name="before"></slot>
    <view>中间固定内容</view>
    <slot name="after"></slot>
  </view>
</template>
```

```html
<!-- 引用方 -->
<my-panel>
  <view slot="before">前置区域</view>
  <view slot="after">后置区域</view>
</my-panel>
```

---

## WXML 模板

小程序 WXML 的 **具名模板**（`<template name>` + `<template is>`）可在**同一组件内联**或通过 **`<import>`** 跨文件复用；跨端输出 RN 时，**内联与 `import` 均已完整支持**。语法与语义与微信保持一致。

### 模板内联定义

在同一页面或组件的 **`<template>` 根内**，用 **`<template name="片段名">`** 定义可复用片段，在同一根下用 **`<template is="片段名" data="{{...}}"/>`** 引用。常用 **`data="{{ ...obj }}"`** 展开对象字段传入模板；**`is` 支持表达式**，可按数据切换不同模板名。

```html
<template>
  <template name="msgItem">
    <view>
      <text>{{ index }}: {{ msg }}</text>
      <text>Time: {{ time }}</text>
    </view>
  </template>

  <template is="msgItem" data="{{ ...item }}" />
</template>
```

```js
createComponent({
  data () {
    return {
      item: { index: 0, msg: 'demo', time: '2026-04-17' }
    }
  }
})
```

**作用域**：模板片段**只能**使用 **`data`** 绑定传入的字段，不能直接读取引用处外层的 `data`（除非通过 `data` 显式传入）。

### import 外联引入

在独立文件（如 `item.wxml`）中用 `<template name="...">` 定义片段；在使用方通过 **`<import src="路径"/>`** 引入后，再用 **`<template is="模板名" data="{{...}}"/>`** 渲染（`is` 同样支持表达式）。

```html
<!-- item.wxml：外联模板文件 -->
<template name="item">
  <text>{{ text }}</text>
</template>
```

```html
<!-- 页面或组件的 <template> 内 -->
<import src="./item.wxml" />
<template is="item" data="{{ text: 'foobar' }}" />
```

**`import` 的作用域**：`import` **只**引入目标文件中**直接定义**的 `template`，**不会**把「目标文件再次 `import` 的其它文件里的 `template`」一并带过来。例如 C import B、B import A：在 C 中可使用 B 定义的模板，不能使用 A 定义的模板，除非 C 再显式 `import` A。



### 注意事项

1. **`is`** 对应的 **`name`** 须在当前可见范围内已定义：内联时在**同一** `<template>` 根内；外联时在 **`import` 已引入** 的文件内。
2. **`import`** 的 **`src`** 为相对路径时相对于当前模板文件，须能被工程构建解析并参与编译。
3. Mpx 跨端输出时不支持使用 `include` 方式引用外联模板，请使用 `import` 方式代替。

---

## i18n 国际化

Mpx 跨端输出 RN 时完整支持 i18n，在模板 Mustache 表达式中可直接调用翻译函数，选项式 API 与组合式 API 均可使用。与输出小程序保持一致。**必须**在构建配置里为 **`MpxWebpackPlugin` 传入 `i18n` 选项**（如 `locale`、`messages` 或 `messagesPath` 等）；未配置时模板与脚本中的翻译调用均无法按预期工作。

### 工程配置示例

在接入 `MpxWebpackPlugin` 时传入 `i18n` 配置（具体挂在 `new MpxWebpackPlugin({...})`、`pluginOptions.mpx.plugin` 等位置以项目脚手架为准）：

```js
i18n: {
  locale: 'zh-CN',
  messages: {
    'zh-CN': {
      message: { hello: '{msg}，你好' }
    },
    'en-US': {
      message: { hello: 'Hello, {msg}' }
    }
  }
  // messagesPath: path.resolve(__dirname, '../src/i18n/messages.js')
  // useComputed: false // 见下方「注意事项」
}
```

### 模板中使用翻译函数

| 场景 | 模板中常用写法 | 说明 |
| --- | --- | --- |
| 选项式 API | `$t`、`$tc`、`$te`、`$tm` | 与 vue-i18n 习惯一致，可在 `{{}}` 与指令属性中书写表达式。 |
| 组合式 API | `t`、`tc`、`te`、`tm` | 须在 `setup` 中通过 **`useI18n()`** 解构，并 **原样名** 放入 `return`，供模板绑定；**禁止** `const { t: t1 } = useI18n()` 后再把 `t1` 交给模板，否则编译期无法正确解析。 |

**选项式：模板 + 指令中的翻译**

```html
<template>
  <view>
    <text wx:if="{{ $te('message.hello') }}">{{ $t('message.hello', { msg: title }) }}</text>
  </view>
</template>

<script>
import { createComponent } from '@mpxjs/core'

createComponent({
  data () {
    return { title: 'Mpx' }
  }
})
</script>
```

**组合式：在模板中使用 `t`（翻译函数需在 `setup` 中导出，且不能随意变更函数名称）**

```html
<template>
  <view>
    <text>{{ t('message.hello', { msg: title }) }}</text>
  </view>
</template>

<script>
import { ref, createComponent, useI18n } from '@mpxjs/core'

createComponent({
  setup () {
    const title = ref('Mpx')
    const { t } = useI18n()
    return {
      title,
      t
    }
  }
})
</script>
```

翻译函数参数、复数文案 `tc`、存在性判断 `te`、消息对象 `tm` 等用法与 vue-i18n 保持一致。

### JS 中使用翻译函数

- **选项式 API**：在 `methods`、`computed`、生命周期钩子等任意可访问组件实例处，使用 **`this.$t` / `this.$tc` / `this.$te` / `this.$tm`**，与 vue-i18n 相同。
- **组合式 API**：在 **`setup`** 函数体内直接调用 **`useI18n()`** 返回的 **`t`/`tc`/`te`/`tm`**，用于拼 **`computed`**、**`watch`**、异步回调等；勿在 `setup` 外闭包中延迟首次调用 `useI18n`（须顶层同步调用）。

**选项式：在逻辑层调用**

```js
import { createComponent } from '@mpxjs/core'

createComponent({
  data () {
    return { userName: 'Lee' }
  },
  ready () {
    const text = this.$t('message.hello', { msg: this.userName })
    console.log(text)
  },
  computed: {
    greeting () {
      return this.$t('message.hello', { msg: this.userName })
    }
  }
})
```

**组合式：列表文案建议在 JS 中先翻译再渲染（多端一致）**

```html
<template>
  <view wx:for="{{ displayList }}" wx:key="id">
    <text>{{ item.label }}</text>
  </view>
</template>

<script>
import { ref, computed, createComponent, useI18n } from '@mpxjs/core'

createComponent({
  setup () {
    const { t } = useI18n()
    const list = ref([
      { id: 1, nameKey: 'apple' },
      { id: 2, nameKey: 'banana' }
    ])
    const displayList = computed(function () {
      return list.value.map(function (item) {
        return {
          id: item.id,
          label: t('fruit.' + item.nameKey)
        }
      })
    })
    return {
      displayList
    }
  }
})
</script>
```

### 注意事项

1. **`useI18n` 须在 `setup` 顶层同步调用**；组合式下模板里出现的翻译函数名必须与 **`useI18n()` 解构名完全一致**（`t`、`tc`、`te`、`tm`），不可重命名后交给模板。
2. 输出小程序且开启 **`i18n.useComputed`** 时，模板中的翻译函数走 computed 注入，**无法引用 `wx:for` 循环体内的 `item` / `index`**。输出 RN 虽不受该机制限制，为与小程序等行为对齐、避免同一模板在不同端表现不一致，**列表场景仍建议在 JS 中先完成翻译**（见上文 `displayList` 示例），避免依赖 `{{ t('key', { x: item }) }}` 仅在部分端可用的写法。
3. **能力边界**：当前与主站一致，仅支持 **`$t` / `$tc` / `$te` / `$tm`（选项式）** 与 **`t` / `tc` / `te` / `tm`（组合式）**；**不支持** **`$d` / `$n`** 等日期、数字格式化 API。
4. **组合式 + 模板**：模板里的 `t`/`tc`/`te`/`tm` 由编译器按 computed 类方式处理，除循环变量问题外，仍需保证 **`return` 中暴露**了模板所需翻译函数，否则对应翻译函数无法在模版中生效。

---

## 无障碍访问

跨端输出 RN 如需支持无障碍访问能力时，模板侧请**优先且统一**使用 **`aria-role`**、**`aria-label`**，与小程序侧写法对齐。**不推荐**在模板里直接书写 RN 文档中的驼峰无障碍属性名（如 **`accessibilityLabel`**、**`accessibilityHint`**、**`accessibilityRole`**、**`accessibilityState`** 等）：这类写法不利于与其它端模板保持一致，也更容易在后续编译或组件封装变动时产生隐性差异。底层 RN 映射由框架与编译规则完成；若需了解语义对应关系，可对照 [RN Accessibility](https://reactnative.dev/docs/accessibility) 作阅读参考，而不是在业务模板中手写 RN 属性名。

### 模板属性

| 模板属性 | 说明 |
| --- | --- |
| `aria-role` | 用于声明按钮、标题、图像等语义角色。 |
| `aria-label` | 用于补充读屏文案。 |

属性值支持 Mustache，例如 `aria-label="{{ desc }}"`。

### 示例

**语义角色 + 读屏文案（推荐写法）**

```html
<template>
  <view
    aria-role="button"
    aria-label="{{ submitText }}"
    bindtap="onSubmit"
  >
    <text>{{ submitText }}</text>
  </view>
</template>
```

### 注意事项

1. **可点击区域**：除可见文案外，为图标按钮等补充 **`aria-label`**，避免读屏仅播报「按钮」而无含义。
2. **与样式隐藏区分**：视觉上用 `wx:show` / 样式隐藏时，仍注意焦点与读屏顺序是否应与视觉一致；若需定义 RN 专有行为，放在 **仅 RN 的条件编译** 中处理，而不是在跨端模板中直接写 RN 无障碍属性名。
3. **多端一致**：小程序与 RN 读屏实现不同，上线前应在 **iOS VoiceOver** 与 **Android TalkBack** 上各测一遍关键路径。

---

## 基础组件

Mpx 输出 RN 内置支持了大部分常用的基础组件，详情见下方文档。

**自定义覆盖与扩展**：当某个内置基础组件在 RN 上不满足业务需要、需替换为自定义实现，或希望在模板中直接使用一组宿主特有的基础组件时，可在 `@mpxjs/webpack-plugin` 的编译配置 `rnConfig.customBuiltInComponents` 中声明自定义组件 —— **同名组件会覆盖**框架内置实现，**新名称则作为扩展基础组件**注入到模板编译期识别表中，无需在每个 `.mpx` 的 `usingComponents` 中重复注册即可在模板中以基础组件方式使用。该配置在模板编译阶段生效，并非应用入口的运行时 `Mpx.config.rnConfig` 配置。

### 通用属性

通用属性除了前述的[模板指令](#模板指令)和[通用事件](#通用事件)绑定外，还包括以下属性：

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| id | string |  | 组件唯一标识 |
| class | string |  | 组件样式类名 |
| style | string |  | 组件内联样式 |
| enable-offset | boolean | `false` | 设置是否要获取组件的布局信息，若设置了该属性，会在 e.target 中返回组件的 offsetLeft、offsetWidth 信息 |
| enable-var | boolean | `true` | 默认支持使用 css variable，若想关闭该功能可设置为 false |
| parent-font-size | number |  | 父组件字体大小，主要用于百分比计算的场景，如 font-size: 100% |
| parent-width | number |  | 父组件宽度，主要用于百分比计算的场景，如 width: calc(100% - 20px)，需要在外部传递父组件的宽度 |
| parent-height | number |  | 父组件高度，主要用于百分比计算的场景，如 height: calc(100% - 20px),需要在外部传递父组件的高度 |

以上基础组件的通用属性仅在 RN 环境中支持。在跨平台输出到小程序或 Web 时，这些属性将无法使用。

由于 view、text、scroll-view、image 和 input 组件都是基于 RN 原生组件实现的，因此这些组件默认继承原生组件支持的属性。

### view

视图容器。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| hover-class | string |  | 指定按下去的样式类。 |
| hover-start-time | number | `50` | 按住后多久出现点击态，单位毫秒 |
| hover-stay-time | number | `400` | 手指松开后点击态保留时间，单位毫秒 |
| animation | object |  | 传递动画的实例， 可配合 mpx.createAnimation 方法一起使用 |
| enable-background | boolean | `false ` | RN 环境特有属性，是否要开启 background-image、background-size 和 background-position 的相关计算或渲染，请根据实际情况开启 |
| enable-animation | boolean | `false` | RN 环境特有属性，开启要开启动画渲染，请根据实际情况开启 |
| enable-fast-image | boolean | `false` | RN 环境特有属性，开启后将使用 react-native-fast-image 进行图片渲染，请根据实际情况开启 |
| is-simple | - | - | RN 环境特有标记，设置后将使用简单版本的 view 组件渲染，该组件不包含 css var、calc、ref 等拓展功能，但性能更优，请根据实际情况设置 |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindtransitionend | 动画结束时触发,`event.detail = { elapsedTime, finished, current }` |

#### 注意事项

- 如果从未使用背景图、动图或动画，请不要开启`enable-background`、`enable-animation`或`enable-fast-image`属性，会有一定的性能消耗。
- 若开启`enable-background`需要给当前 view 组件设置一个唯一 key。
- `background-image`、`background-size`、`background-position` 等背景图相关 css 属性，仅 view 组件支持
- 出于性能考虑，基础组件的样式增强能力（如 `enable-var`、`enable-background`、`enable-animation`）采用按需启用策略。view 组件仅在**首次**渲染时检测样式并决定是否开启对应能力。由于 React Hooks 的一致性约束，增强能力无法在后续更新阶段再动态启用，因此当组件生命周期内**可能**使用相关能力时，需在首次渲染时**显式声明**启用，比如 <span v-pre>`enable-animation="{{ true }}"`</span>。

### text

文本。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| user-select | boolean | `false` | 文本是否可选。 |
| selectable | boolean | `false` | 文本是否可选。该属性已废弃，请使用 user-select |
| decode | boolean | `false` | 是否解码 |
| is-simple | - | - | RN 环境特有标记，设置后将使用简单版本的 text 组件渲染，该组件不包含 css var、calc、ref 等拓展功能，但性能更优，请根据实际情况设置 |

#### 注意事项

- 未包裹 text 标签的文本，会自动包裹 text 标签。
- text 组件开启 enable-offset 后，offsetLeft、offsetWidth 获取时机仅为组件首次渲染阶段

### scroll-view

可滚动视图区域。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| scroll-x | boolean | `false` | 允许横向滚动 |
| scroll-y | boolean | `false` | 允许纵向滚动 |
| upper-threshold | number | `50` | 距顶部/左边多远时(单位 px),触发 scrolltoupper 事件 |
| lower-threshold | number | `50` | 距底部/右边多远时(单位 px),触发 scrolltolower 事件 |
| scroll-top | number | `0` | 设置纵向滚动条位置 |
| scroll-left | number | `0` | 设置横向滚动条位置 |
| scroll-with-animation | boolean | `false` | 在设置滚动条位置时使用动画过渡 |
| enable-back-to-top | boolean | `false` | 点击状态栏的时候视图会滚动到顶部，仅 iOS 环境支持 |
| enhanced | boolean | `false` | scroll-view 组件功能增强 |
| bounces | boolean | `true` | iOS 下 scroll-view 边界弹性控制 (同时开启 enhanced 属性后生效) |
| refresher-enabled | boolean | `false` | 开启自定义下拉刷新 |
| refresher-threshold | number | `45` | 设置自定义下拉刷新阈值 |
| scroll-into-view | string |  | 值应为某子元素 id（id 不能以数字开头） |
| scroll-into-view-offset | number | `0` | 跳转到 scroll-into-view 目标节点时的额外偏移 |
| refresher-default-style | string | `'black'` | 设置下拉刷新默认样式,支持 `black`、`white`、`none`，仅安卓支持 |
| refresher-background | string | `'#fff'` | 设置自定义下拉刷新背景颜色，仅安卓支持 |
| refresher-triggered | boolean | `false` | 设置当前下拉刷新状态,true 表示已触发 |
| paging-enabled | boolean | `false` | 分页滑动效果 (同时开启 enhanced 属性后生效)，当值为 true 时，滚动条会停在滚动视图的尺寸的整数倍位置 |
| show-scrollbar | boolean | `true` | 滚动条显隐控制 (同时开启 enhanced 属性后生效) |
| enable-trigger-intersection-observer | boolean | `false` | RN 环境特有属性，是否开启 intersection-observer |
| simultaneous-handlers | array\<object> | `[]` | RN 环境特有属性，主要用于组件嵌套场景，允许多个手势同时识别和处理并触发，这个属性可以指定一个或多个手势处理器，处理器支持使用 this.$refs.xxx 获取组件实例来作为数组参数传递给 scroll-view 组件 |
| wait-for | array\<object> | `[]` | RN 环境特有属性，主要用于组件嵌套场景，允许延迟激活处理某些手势，这个属性可以指定一个或多个手势处理器，处理器支持使用 this.$refs.xxx 获取组件实例来作为数组参数传递给 scroll-view 组件 |
| scroll-event-throttle | number | `0` | RN 环境特有属性，控制 scroll 事件触发频率 |
| enable-sticky | boolean | `false` | RN 环境特有属性，当使用 sticky 组件时，需要手动将此属性设置为 true |

#### 事件

| 事件名               | 说明                                       |
| -------------------- | ------------------------------------------ |
| binddragstart        | 滑动开始事件，同时开启 enhanced 属性后生效 |
| binddragging         | 滑动事件，同时开启 enhanced 属性后生效     |
| binddragend          | 滑动结束事件，同时开启 enhanced 属性后生效 |
| bindscrolltoupper    | 滚动到顶部/左边触发                        |
| bindscrolltolower    | 滚动到底部/右边触发                        |
| bindscroll           | 滚动时触发                                 |
| bindscrollend        | 滚动结束时触发                             |
| bindrefresherrefresh | 自定义下拉刷新被触发                       |

#### 注意事项

- 若使用 scroll-into-view 属性，需要 id 对应的组件节点添加 wx:ref 标记，否则无法正常滚动。另外组件节点需要是内置基础组件，自定义组件暂不支持。
- simultaneous-handlers 为 RN 环境特有属性，具体含义可参考[react-native-gesture-handler](https://docs.swmansion.com/react-native-gesture-handler/docs/fundamentals/gesture-composition/#simultaneouswithexternalgesture)
- wait-for 为 RN 环境特有属性，具体含义可参考[react-native-gesture-handler](https://docs.swmansion.com/react-native-gesture-handler/docs/fundamentals/gesture-composition/#requireexternalgesturetofail)
- scroll-view 组件在滚动过程中，不会触发其自身或子组件的 touchend 事件响应，这是 RN 底层实现导致的问题，手势系统识别当前是 scroll-view 的滚动，就会取消掉 touchend 事件的响应。
- 安卓上如果触发了 scroll-view 组件默认的下拉刷新，binddragend 可能不触发，只会触发 binddragstart

### swiper

滑块视图容器。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| indicator-dots | boolean | `false` | 是否显示面板指示点 |
| indicator-color | color | `rgba(0, 0, 0, .3)` | 指示点颜色 |
| indicator-active-color | color | `#000000` | 当前选中的指示点颜色 |
| indicator-width | number |  | 指示点宽度 |
| indicator-height | number |  | 指示点高度 |
| indicator-spacing | number |  | 指示点间距 |
| indicator-radius | number |  | 指示点圆角 |
| indicator-margin | number |  | 指示点外边距 |
| autoplay | boolean | `false` | 是否自动切换 |
| current | number | `0` | 当前所在滑块的 index |
| interval | number | `5000` | 自动切换时间间隔 |
| duration | number | `500` | 滑动动画时长 |
| circular | boolean | `false` | 是否采用衔接滑动 |
| vertical | boolean | `false` | 滑动方向是否为纵向 |
| previous-margin | string | `0` | 前边距，可用于露出前一项的一小部分，接受 px |
| next-margin | string | `0` | 后边距，可用于露出后一项的一小部分，接受 px |
| scale | boolean | `false` | 滑动时是否开启前后元素缩小,默认是缩放 0.7 倍, 暂不支持自定义 |
| easing-function | string | `linear` | 支持 linear、easeInCubic、easeOutCubic、easeInOutCubic |
| simultaneous-handlers | array\<object> | `[]` | RN 环境特有属性，主要用于组件嵌套场景，允许多个手势同时识别和处理并触发，这个属性可以指定一个或多个手势处理器，处理器支持使用 this.$refs.xxx 获取组件实例来作为数组参数传递给 swiper 组件 |
| wait-for | array\<object> | `[]` | RN 环境特有属性，主要用于组件嵌套场景，允许延迟激活处理某些手势，这个属性可以指定一个或多个手势处理器，处理器支持使用 this.$refs.xxx 获取组件实例来作为数组参数传递给 swiper 组件 |
| disableGesture | boolean | `false` | RN 环境特有属性，禁用 swiper 滑动手势。若开启用户无法通过手势滑动 swiper，只能通过开启 autoPlay 进行自动轮播 |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindchange | current 改变时会触发 change 事件，`event.detail = {current, source}` |

### swiper-item

仅可放置在 swiper 组件中，宽高自动设置为 100%。

#### 属性

| 属性名  | 类型   | 默认值 | 说明                    |
| ------- | ------ | ------ | ----------------------- |
| item-id | string |        | 该 swiper-item 的标识符 |

### movable-area

movable-view 的可移动区域。

### movable-view

可移动的视图容器，在页面中可以拖拽滑动。movable-view 必须在 movable-area 组件中，并且必须是直接子节点，否则不能移动。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| direction | string | `none` | 目前支持 all、vertical、horizontal、none |
| inertia | boolean | `false` | movable-view 是否带有惯性 |
| out-of-bounds | boolean | `false` | 超过可移动区域后，movable-view 是否还可以移动 |
| x | number |  | 定义 x 轴方向的偏移 |
| y | number |  | 定义 y 轴方向的偏移 |
| disabled | boolean | `false` | 是否禁用 |
| animation | boolean | `true` | 是否使用动画 |
| damping | number | `20` | 阻尼系数，用于控制 x 或 y 改变时的动画和过界回弹的动画，值越大移动越快 |
| friction | number | `2` | 摩擦系数，用于控制惯性滑动的动画，值越大摩擦力越大，滑动越快停止 |
| simultaneous-handlers | array\<object> | `[]` | RN 环境特有属性，主要用于组件嵌套场景，允许多个手势同时识别和处理并触发，这个属性可以指定一个或多个手势处理器，处理器支持使用 this.$refs.xxx 获取组件实例来作为数组参数传递给 movable-view 组件 |
| wait-for | array\<object> | `[]` | RN 环境特有属性，主要用于组件嵌套场景，允许延迟激活处理某些手势，这个属性可以指定一个或多个手势处理器，处理器支持使用 this.$refs.xxx 获取组件实例来作为数组参数传递给 movable-view 组件 |
| disable-event-passthrough | boolean | `false` | RN 环境特有属性，有时候我们希望 movable-view 在水平方向滑动，并且竖直方向的手势也希望被 movable-view 组件消费掉，不被其他组件响应，可以将这个属性设置为 true） |

#### 事件

| 事件名     | 说明                                                  |
| ---------- | ----------------------------------------------------- |
| bindchange | 拖动过程中触发的事件，`event.detail = {x, y, source}` |
| htouchmove | 初次手指触摸后移动为横向的移动时触发                  |
| vtouchmove | 初次手指触摸后移动为纵向的移动时触发                  |

#### 注意事项

- simultaneous-handlers 为 RN 环境特有属性，具体含义可参考[react-native-gesture-handler](https://docs.swmansion.com/react-native-gesture-handler/docs/fundamentals/gesture-composition/#simultaneouswithexternalgesture)
- wait-for 为 RN 环境特有属性，具体含义可参考[react-native-gesture-handler](https://docs.swmansion.com/react-native-gesture-handler/docs/fundamentals/gesture-composition/#requireexternalgesturetofail)
- RN 环境 movable 相关组件暂不支持缩放能力

### image

图片组件

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| src | string | `false` | 图片资源地址、base64 格式数据或本地静态资源相对路径 |
| mode | string | `scaleToFill` | 图片裁剪、缩放的模式，可选值为 `scaleToFill`、`aspectFit`、`aspectFill`、`widthFix`、`heightFix`、`top`、`bottom`、`center`、`left`、`right`、`top left`、`top right`、`bottom left`、`bottom right` |
| enable-fast-image | boolean | `false` | RN 环境特有属性，开启后将使用 react-native-fast-image 进行图片渲染，请根据实际情况开启 |
| is-svg | boolean | `false` | RN 环境特有属性，传递为 `true` 时强制使用 SVG 方式渲染图片 |

#### 事件

| 事件名    | 说明                                                     |
| --------- | -------------------------------------------------------- |
| binderror | 当错误发生时触发，`event.detail = { errMsg }`            |
| bindload  | 当图片载入完毕时触发，`event.detail = { height, width }` |

#### 注意事项

- image 组件默认宽度 320px、高度 240px
- image 组件进行缩放时，计算出来的宽高可能带有小数，在不同 webview 内核下渲染可能会被抹去小数部分
- RN 输出支持 `<image src="./logo.png" />` / `<image src="./icon.svg" />` 这类本地静态资源写法，编译后会通过 webpack 资源 loader 处理；动态绑定本地图片时建议在脚本中 `import` 后再绑定。

### icon

图标组件

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| type | string |  | icon 的类型，有效值：success、success_no_circle、info、warn、waiting、cancel、download、search、clear |
| size | string\|number | `23` | icon 的大小 |
| color | string |  | icon 的颜色，同 css 的 color |

### button

按钮。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| size | string | `default` | 按钮的大小，`default`：默认大小，`mini`：小尺寸 |
| type | string | `default` | 按钮的样式类型，`primary`：绿色，`default`：白色，`warn`：红色 |
| plain | boolean | `false` | 按钮是否镂空，背景色透明 |
| disabled | boolean | `false` | 是否禁用 |
| loading | boolean | `false` | 名称前是否带 loading 图标 |
| form-type | string |  | 用于 form 组件，点击分别会触发 form 组件的 submit/reset 事件，有效值为 `submit`、`reset` |
| open-type | string |  | 微信开放能力，当前仅支持 `share` 和 `getUserInfo` |
| hover-class | string |  | 指定按钮按下去的样式类。当 hover-class="none" 时，没有点击态效果 |
| hover-start-time | number | `20` | 按住后多久出现点击态，单位毫秒 |
| hover-stay-time | number | `70` | 手指松开后点击态保留时间，单位毫秒 |

#### 注意事项

- openType 需要在 `mpx.config.rnConfig` 中注册对应能力如 `onShareAppMessage`、`onUserInfo` 来配合使用。

### label

用来改进表单组件的可用性

#### 注意事项

- 当前不支持使用 for 属性找到对应 id，仅支持将控件放在该标签内，目前可以绑定的控件有：checkbox、radio、switch。

### checkbox

多选项目

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| value | string |  | checkbox 标识，选中时触发 checkbox-group 的 change 事件，并携带 checkbox 的 value |
| disabled | boolean | `false` | 是否禁用 |
| checked | boolean | `false` | 当前是否选中，可用来设置默认选中 |
| color | string | `#09BB07` | checkbox 的颜色，同 css 的 color |

### checkbox-group

多项选择器，内部由多个 checkbox 组成。

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindchange | checkbox-group 中选中项发生改变时触发 change 事件，`detail = { value: [ 选中的 checkbox 的 value 的数组 ] } ` |

### radio

单选项目

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| value | string |  | radio 标识，当该 radio 选中时，radio-group 的 change 事件会携带 radio 的 value |
| disabled | boolean | false | 是否禁用 |
| checked | boolean | false | 当前是否选中，可用来设置默认选中 |
| color | string | #09BB07 | checkbox 的颜色，同 css 的 color |

### radio-group

单项选择器，内部由多个 radio 组成

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindchange | radio-group 中选中项发生改变时触发 change 事件，`detail = { value: [ 选中的 radio 的 value 的数组 ] }` |

### form

表单。

当点击 form 表单中 form-type 为 submit 的 button 组件时，会将表单组件中的 value 值进行提交，需要在表单组件中加上 name 来作为 key。

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindsubmit | 携带 form 中的数据触发 submit 事件，`event.detail = {value : {'name': 'value'} }` |
| bindreset | 表单重置时会触发 reset 事件 |

### input

输入框。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| value | string |  | 输入框的初始内容 |
| type | string | `text` | input 的类型，可选值为 `text`、`number`、`idcard`、`digit`，不支持 `safe-password`、`nickname` |
| password | boolean | `false` | 是否是密码类型 |
| placeholder | string |  | 输入框为空时占位符 |
| placeholder-class | string |  | 指定 placeholder 的样式类，仅支持 color 属性 |
| placeholder-style | string |  | 指定 placeholder 的样式，仅支持 color 属性 |
| disabled | boolean | `false` | 是否禁用 |
| maxlength | number | `140` | 最大输入长度，设置为 -1 的时候不限制最大长度 |
| cursor-spacing | number | `0` | 指定光标与键盘的距离，单位 px。取 input 距离底部的距离和 cursor-spacing 指定的距离的最小值作为光标与键盘的距离 |
| auto-focus | boolean | `false` | (即将废弃，请直接使用 focus )自动聚焦，拉起键盘 |
| focus | boolean | `false` | 获取焦点 |
| confirm-type | string | `done` | 设置键盘右下角按钮的文字，仅在 type='text' 时生效，可选值为 `send`、`search`、`next`、`go`、`done`、`return` |
| hold-keyboard | boolean | `false` | 输入框聚焦时，点击页面其他地方是否收起键盘 <badge type="tip" text="2.10.18+" /> |
| cursor | number |  | 指定 focus 时的光标位置 |
| cursor-color | string |  | 光标颜色 |
| selection-start | number | `-1` | 光标起始位置，自动聚集时有效，需与 selection-end 搭配使用 |
| selection-end | number | `-1` | 光标结束位置，自动聚集时有效，需与 selection-start 搭配使用 |
| adjust-position | boolean | `true` | 键盘弹起时，是否自动上推页面 |
| keyboard-type | string |  | RN 环境特有属性，设置键盘类型 |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindinput | 键盘输入时触发，`event.detail = { value, cursor }`，不支持 `keyCode` |
| bindfocus | 输入框聚焦时触发，`event.detail = { value }`，不支持 `height` |
| bindblur | 输入框失去焦点时触发，`event.detail = { value }`，不支持 `encryptedValue`、`encryptError` |
| bindconfirm | 点击完成按钮时触发，`event.detail = { value }` |
| bind:selectionchange | 选区改变事件, `event.detail = { selectionStart, selectionEnd }` |

### textarea

多行输入框。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| value | string |  | 输入框内容 |
| placeholder | string |  | 输入框为空时占位符 |
| placeholder-class | string |  | 指定 placeholder 的样式类，仅支持 color 属性 |
| placeholder-style | string |  | 指定 placeholder 的样式，仅支持 color 属性 |
| disabled | boolean | `false` | 是否禁用 |
| maxlength | number | `140` | 最大输入长度，设置为 -1 的时候不限制最大长度 |
| cursor-spacing | number | `0` | 指定光标与键盘的距离，单位 px。取 textarea 距离底部的距离和 cursor-spacing 指定的距离的最小值作为光标与键盘的距离 |
| auto-focus | boolean | `false` | (即将废弃，请直接使用 focus )自动聚焦，拉起键盘 |
| focus | boolean | `false` | 获取焦点 |
| auto-height | boolean | `false` | 是否自动增高，设置 auto-height 时，style.height 不生效 |
| confirm-type | string | `return` | 设置键盘右下角按钮的文字，可选值为 `send`、`search`、`next`、`go`、`done`、`return` |
| confirm-hold | boolean | `false` | 点击键盘右下角按钮时是否保持键盘不收起 |
| hold-keyboard | boolean | `false` | 输入框聚焦时，点击页面其他地方是否收起键盘 <badge type="tip" text="2.10.18+" /> |
| cursor | number |  | 指定 focus 时的光标位置 |
| cursor-color | string |  | 光标颜色 |
| selection-start | number | `-1` | 光标起始位置，自动聚集时有效，需与 selection-end 搭配使用 |
| selection-end | number | `-1` | 光标结束位置，自动聚集时有效，需与 selection-start 搭配使用 |
| adjust-position | boolean | `true` | 键盘弹起时，是否自动上推页面 |
| keyboard-type | string |  | RN 环境特有属性，设置键盘类型 |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindinput | 键盘输入时触发，`event.detail = { value, cursor }`，不支持 `keyCode` |
| bindfocus | 输入框聚焦时触发，`event.detail = { value }`，不支持 `height` |
| bindblur | 输入框失去焦点时触发，`event.detail = { value }`，不支持 `encryptedValue`、`encryptError` |
| bindconfirm | 点击完成按钮时触发，`event.detail = { value }` |
| bindlinechange | 输入框行数变化时调用，`event.detail = { height: 0, lineCount: 0 }`，不支持 `heightRpx` |
| bind:selectionchange | 选区改变事件, `event.detail = {selectionStart, selectionEnd}` |

#### 注意事项

- textarea 组件不支持 `confirm-hold` 属性。

### progress

进度条。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| percent | number | `0` | 百分比进度，范围 0-100 |
| stroke-width | number\|string | `6` | 进度条线的宽度，单位 px |
| color | string |  | 进度条颜色（已废弃，请使用 activeColor） |
| activeColor | string | `#09BB07` | 已选择的进度条的颜色 |
| backgroundColor | string | `#EBEBEB` | 未选择的进度条的颜色 |
| active | boolean | `false` | 进度条从左往右的动画 |
| active-mode | string | `backwards` | 动画播放模式，`backwards`: 从头开始播放；`forwards`: 从上次结束点接着播放 |
| duration | number | `30` | 进度增加 1%所需毫秒数 |

#### 事件

| 事件名        | 说明                                         |
| ------------- | -------------------------------------------- |
| bindactiveend | 动画完成时触发，`event.detail = { percent }` |

#### 注意事项

- 不支持 `show-info` 属性，即不支持在进度条右侧显示百分比
- 不支持 `border-radius` 属性自定义圆角大小
- 不支持 `font-size` 属性设置右侧百分比字体大小

### picker-view

嵌入页面的滚动选择器。其中只可放置 [picker-view-column](#picker-view-column) 组件，其它节点不会显示

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| value | array\<number\> | `[]` | 数组中的数字依次表示 picker-view 内的 [picker-view-column](#picker-view-column) 选择的第几项（下标从 0 开始），数字大于 [picker-view-column](#picker-view-column) 可选项长度时，选择最后一项。 |
| indicator-style | string |  | 设置选择器中间选中框的样式 |
| indicator-class | string |  | 设置选择器中间选中框的类名 |
| mask-style | string |  | 设置蒙层的样式 |
| mask-class | string |  | 设置蒙层的类名 |
| enable-wheel-animation | boolean | `true` | RN 环境特有属性，是否开启滚轮滚动动画效果 <badge type="tip" text="2.10.17+" /> |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindchange | 滚动选择时触发 change 事件，`event.detail = {value}`，其中 `value` 为数组，表示 picker-view 内的 [picker-view-column](#picker-view-column) 当前选择的是第几项（下标从 0 开始） |

触感反馈回调方法

通过在全局注册 `mpx.config.rnConfig.onPickerVibrate` 方法，在每次滚动选择时会调用该方法。

| 注册触感方法名 | 类型 | 说明 |
| --- | --- | --- |
| onPickerVibrate | Function | 注册自定义触感反馈方法。调用时机：在每次滚动选择时会调用该方法。可以在方法内自定义实现类似 iOS 端原生表盘的振动触感。 |

### picker-view-column

滚动选择器子项。仅可放置于 [picker-view](#picker-view) 中，其孩子节点的高度会自动设置成与 [picker-view](#picker-view) 的选中框的高度一致

### picker

从底部弹起的滚动选择器。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| mode | string | `selector` | 选择器类型，目前支持 `selector`、 `multiSelector`、 `time`、 `date`、 `region` |
| disabled | boolean | `false` | 是否禁用 |
| header-text | string |  | 头部标题 |

#### 事件

| 事件名     | 说明                                                   |
| ---------- | ------------------------------------------------------ |
| bindcancel | 取消选择时触发                                         |
| bindchange | value 改变时触发 change 事件，`event.detail = {value}` |

#### 普通选择器：mode = selector

##### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| range | array[object]/array | `[]` | mode 为 selector 或 multiSelector 时，range 有效 |
| range-key | string | `false` | 当 range 是一个 Object Array 时，通过 range-key 来指定 Object 中 key 的值作为选择器显示内容 |
| value | number | 0 | 表示选择了 range 中的第几个（下标从 0 开始） |

#### 多列选择器：mode = multiSelector

##### 属性与事件

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| range | array[object]/array | `[]` | mode 为 selector 或 multiSelector 时，range 有效 |
| range-key | string | `false` | 当 range 是一个 Object Array 时，通过 range-key 来指定 Object 中 key 的值作为选择器显示内容 |
| value | array | `[]` | 表示选择了 range 中的第几个（下标从 0 开始） |
| bindcolumnchange | function |  | 列改变时触发 |

#### 多列选择器：时间选择器：mode = time

##### 属性

| 属性名 | 类型   | 默认值  | 说明                                        |
| ------ | ------ | ------- | ------------------------------------------- |
| value  | string | `[]`    | 表示选中的时间，格式为"hh:mm"               |
| start  | string | `false` | 表示有效时间范围的开始，字符串格式为"hh:mm" |
| end    | string | `[]`    | 表示有效时间范围的结束，字符串格式为"hh:mm" |

#### 多列选择器：时间选择器：mode = date

##### 属性

| 属性名 | 类型   | 默认值  | 说明                                             |
| ------ | ------ | ------- | ------------------------------------------------ |
| value  | string | `当天`  | 表示选中的日期，格式为"YYYY-MM-DD"               |
| start  | string | `false` | 表示有效日期范围的开始，字符串格式为"YYYY-MM-DD" |
| end    | string | `[]`    | 表示有效日期范围的结束，字符串格式为"YYYY-MM-DD" |
| fields | string | `day`   | 有效值 year,month,day，表示选择器的粒度          |

fields 有效值： | 属性名 | 说明 | | -----------------------| ------------------------ | | year | 选择器粒度为年 | | month | 选择器粒度为月份 | | day | 选择器粒度为天 |

#### 省市区选择器：mode = region

##### 属性

| 属性名      | 类型   | 默认值   | 说明                                       |
| ----------- | ------ | -------- | ------------------------------------------ |
| value       | array  | `[]`     | 表示选中的省市区，默认选中每一列的第一个值 |
| custom-item | string |          | 可为每一列的顶部添加一个自定义的项         |
| level       | string | `region` | 选择器层级                                 |

level 有效值：

| 属性名   | 说明         |
| -------- | ------------ |
| province | 选省级选择器 |
| city     | 市级选择器   |
| region   | 区级选择器   |

### slider

滑动选择器。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| min | number | `0` | 最小值 |
| max | number | `100` | 最大值 |
| step | number | `1` | 步长 |
| disabled | boolean | `false` | 是否禁用 |
| value | number | `min` | 当前取值 |
| color | string |  | 背景条颜色（已废弃，请使用 backgroundColor） |
| selected-color | string |  | 已选择颜色（已废弃，请使用 activeColor） |
| activeColor | string | `#1aad19` | 已选择颜色 |
| backgroundColor | string | `#e9e9e9` | 背景条颜色 |
| block-size | number | `28` | 滑块大小，RN 侧会限制在 12 到 28 之间 |
| block-color | string | `#ffffff` | 滑块颜色 |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindchange | 完成一次拖动后触发，`event.detail = { value }` |
| bindchanging | 拖动过程中触发，`event.detail = { value }` |

#### 注意事项

- 不支持 `show-value` 属性，即不支持在滑动条右侧显示当前 value。

### switch

开关选择器。

#### 属性

| 属性名   | 类型    | 默认值    | 说明                           |
| -------- | ------- | --------- | ------------------------------ |
| checked  | boolean | `false`   | 是否选中                       |
| disabled | boolean | `false`   | 是否禁用                       |
| type     | string  | `switch`  | 样式，有效值：switch, checkbox |
| color    | string  | `#04BE02` | switch 的颜色，同 css 的 color |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindchange | 点击导致 checked 改变时会触发 change 事件，`event.detail = { value }` |

### navigator

页面链接。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| hover-class | string | `false` | 指定按下去的样式类。 |
| hover-start-time | number | `50` | 按住后多久出现点击态，单位毫秒 |
| hover-stay-time | number | `400` | 手指松开后点击态保留时间，单位毫秒 |
| open-type | string | `navigate` | 可支持`navigateBack`、`redirect`、`switchTab`、`reLaunch`、`navigateTo` |
| url | string |  | 跳转链接 |
| delta | number |  | 当 open-type 为 'navigateBack' 时有效，表示回退的层数 |

### rich-text

富文本。

#### 属性

| 属性名 | 类型          | 默认值 | 说明     |
| ------ | ------------- | ------ | -------- |
| nodes  | array\|string | []     | 节点列表 |

### canvas

画布。

#### 事件

| 事件名          | 说明                                              |
| --------------- | ------------------------------------------------- |
| bindtouchstart  | 手指触摸动作开始                                  |
| bindtouchmove   | 手指触摸后移动                                    |
| bindtouchend    | 手指触摸动作结束                                  |
| bindtouchcancel | 手指触摸动作被打断                                |
| bindlongtap     | 手指长按 350ms 之后触发                           |
| binderror       | 当发生错误时触发 error 事件， `detail = {errMsg}` |

#### API

| 方法名          | 说明                                                      |
| --------------- | --------------------------------------------------------- |
| createImage     | 创建一个图片对象。 仅支持在 2D Canvas 中使用              |
| createImageData | 创建一个 ImageData 对象。仅支持在 2D Canvas 中使用        |
| getContext      | 该方法返回 Canvas 的绘图上下文。仅支持在 2D Canvas 中使用 |
| toDataURL       | 返回一个包含图片展示的 data URI                           |

#### 注意事项

- canvas 组件目前仅支持 2D 类型，不支持 webgl
- 通过 Canvas.getContext('2d') 接口可以获取 CanvasRenderingContext2D 对象，具体接口可以参考 [HTML Canvas 2D Context](https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D) 定义的属性、方法
- canvas 的实现主要借助于 PostMessage 方式与 webview 容器通信进行绘制，所以对于严格依赖方法执行时机的场景，如调用 drawImage 绘图，再通过 getImageData 获取图片数据的场景，调用时需要使用 await 等方式来保证方法的执行时机
- 通过 Canvas.createImage 画图，图片的链接不能有特殊字符，安卓手机可能会 load 失败

### camera

系统相机。

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| mode | string | `normal` | 应用模式，可选值为 `normal`、`scanCode` |
| resolution | string | `medium` | 分辨率，可选值为 `low`、`medium`、`high` |
| device-position | string | `back` | 摄像头朝向，可选值为 `front`、`back` |
| flash | string | `auto` | 闪光灯，可选值为 `auto`、`on`、`off` |
| frame-size | string | `medium` | 指定期望的相机帧数据尺寸，可选值为 `small`、`medium`、`large` |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindinitdone | 相机初始化完成时触发，`event.detail = { maxZoom }` |
| bindstop | 摄像头在非正常终止时触发 |
| binderror | 相机发生错误时触发 |
| bindscancode | 在 `scanCode` 模式下识别到二维码时触发，`event.detail = { result, type, scanArea }` |

#### API

| 方法名 | 说明 |
| --- | --- |
| setZoom | 设置缩放级别 |
| takePhoto | 拍照，仅支持在 `normal` 模式中使用 |
| startRecord | 开始录像 |
| stopRecord | 结束录像 |

#### 注意事项

- camera 组件基于第三方库 `react-native-vision-camera` 来实现，需要容器中安装此依赖包并完成相机权限配置。

### video

视频

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| src | string |  | 要播放视频的资源地址或本地静态资源相对路径 |
| controls | boolean | `true` | 是否显示默认播放控件 |
| autoplay | boolean | `false` | 是否自动播放 |
| loop | boolean | `false` | 是否循环播放 |
| muted | boolean | `false` | 是否静音播放 |
| initial-time | number | `0` | 指定视频初始播放位置 |
| object-fit | string | `contain` | 当视频大小与 video 容器大小不一致时，视频的表现形式 |
| poster | string |  | 视频封面的图片地址 |
| enable-auto-rotation | boolean | `false` | 是否开启手机横屏时自动全屏，当系统设置开启自动旋转时生效，仅 ios 支持 |
| preferred-peak-bit-rate | number | `0` | 指定码率上界，单位为比特每秒 |
| is-drm | boolean | `false` | 是否为 drm 视频 |
| provision-url | string |  | android 环境特有属性，drm 视频的 provision url |
| certificate-url | string |  | ios 环境特有属性，drm 视频的 certificate url |
| license-url | string |  | drm 视频的 license url |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindplay | 当开始/继续播放时触发 play 事件 |
| bindpause | 当暂停播放时触发 pause 事件 |
| bindended | 当播放到末尾时触发 ended 事件 |
| bindtimeupdate | 播放进度变化时触发，`event.detail = {currentTime, duration}` |
| bindfullscreenchange | 视频进入和退出全屏时触发，`event.detail = {fullScreen` } |
| bindwaiting | 视频出现缓冲时触发 |
| binderror | 视频播放出错时触发 |
| bindloadedmetadata | 视频元数据加载完成时触发。`event.detail = {width, height, duration}` |
| bindcontrolstoggle | 切换 controls 显示隐藏时触发。`event.detail = {show}` |
| bindseekcomplete | seek 完成时触发 |

#### 注意事项

- 手动拖拽进度条场景，bindseekcomplete 事件，android 可以触发，ios 不支持
- video 组件基于第三方库 `react-native-video` 来实现，需要容器中安装此依赖包

### web-view

承载网页的容器。会自动铺满整个 RN 页面

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| src | string |  | webview 指向网页的链接，如果需要对跳转的 URL 设定白名单可跳转，需要在业务跳转之前处理该逻辑 |

#### 事件

| 事件名      | 说明                                |
| ----------- | ----------------------------------- |
| bindmessage | 网页向 RN 通过 postMessage 传递数据 |
| bindload    | 网页加载成功时候触发此事件          |
| binderror   | 网页加载失败的时候触发此事件        |

#### 注意事项

- 被打开的 H5 页面需使用 `@mpxjs/webview-bridge@2.9.68` 及以上版本与 RN 容器进行通信，具体通信方式参见 [Webview API](#webview-api)

### root-portal

使整个子树从页面中脱离出来，类似于在 CSS 中使用 position: fixed 的效果。主要用于制作弹窗、弹出层等。

#### 属性

| 属性名 | 类型    | 默认值 | 说明                 |
| ------ | ------- | ------ | -------------------- |
| enable | boolean | `true` | 是否从页面中脱离出来 |

#### 注意事项

- style 样式中不支持使用百分比计算、css variable

### sticky-section

吸顶布局容器，仅支持作为 `<scroll-view>` 的直接子节点

#### 注意事项

- sticky-section 目前仅支持 RN、web 以及微信小程序环境，其他环境暂不支持。微信小程序中使用需开启 skyline 渲染模式

### sticky-header

吸顶布局容器，仅支持作为 `<scroll-view>` 的直接子节点或 `sticky-section` 组件直接子节点

#### 属性

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| offset-top | number | `0` | 吸顶时与顶部的距离 |
| padding | array | `[0, 0, 0, 0] ` | 长度为 4 的数组，按 top、right、bottom、left 顺序指定内边距 |

#### 事件

| 事件名 | 说明 |
| --- | --- |
| bindstickontopchange | 吸顶状态变化事件, `event.detail = { isStickOnTop }`，当 sticky-header 吸顶时为 true，否则为 false |

#### 注意事项

- sticky-header 目前仅支持 RN、web 以及微信小程序环境，其他环境暂不支持。微信小程序中使用需开启 skyline 渲染模式
- RN 环境的 sticky-header 更适用于内容稳定、状态不常变更的场景使用，目前如果 sticky 还在动画过程中就触发组件更新（如在 bindstickontopchange 回调中立刻更新 state）、scroll-view 内容高度由多变少、通过修改 scroll-into-view、scroll-top 让 scroll-view 滚动，以上场景在安卓上都可能会导致闪烁或抖动

### cover-view

视图容器。功能同 [view 组件](#view)，在 cover-view 中只能嵌套 cover-view 或 cover-image 组件。

### cover-image

视图容器。功能同 [image 组件](#image)
